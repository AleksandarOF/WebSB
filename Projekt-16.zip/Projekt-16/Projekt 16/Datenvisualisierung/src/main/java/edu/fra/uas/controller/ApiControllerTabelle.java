package edu.fra.uas.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import edu.fra.uas.model.Tabelle;
import edu.fra.uas.repository.TabelleRepository;

@RestController
@RequestMapping(value = "/api/table_form") // Hier finden wir alle gegeben Dateien in der JSON
public class ApiControllerTabelle {

	@Autowired
	private TabelleRepository repository;

	// GET request to retrieve table data
	@GetMapping
	public ResponseEntity<List<Tabelle>> getAll() {
		return new ResponseEntity<>(this.repository.findAll(), HttpStatus.OK);

	}

	// POST request to save table data
	@PostMapping()
	public ResponseEntity<String> saveTabelle(@RequestBody Tabelle tabelle) {
		this.repository.save(tabelle);
		return new ResponseEntity<>("Tabelle is saved", HttpStatus.ACCEPTED);
	}

}
