package edu.fra.uas.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.fra.uas.model.PieChart;
import edu.fra.uas.repository.PieChartRepository;

@RestController
@RequestMapping(value = "/api/pieChart", produces = MediaType.APPLICATION_JSON_VALUE)
public class ApiControllerPieChart {

	@Autowired
	private PieChartRepository repository;

	// GET request to retrieve all pie chart data
	@GetMapping
	public ResponseEntity<List<PieChart>> getAll() {
		return new ResponseEntity<>(this.repository.findAll(), HttpStatus.OK);

	}

	// POST request to save pie chart data
	@PostMapping()
	public ResponseEntity<String> savePieChart(@RequestBody PieChart piechart) {
		this.repository.save(piechart);
		return new ResponseEntity<>("PieChart is saved", HttpStatus.ACCEPTED);
	}
}
