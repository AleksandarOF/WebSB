package edu.fra.uas.config;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.fra.uas.repository.BarchartRepositoryValue;

//This class initializes the database with default values for Barchart if needed.

@Component
public class InitDBBarchart {

	@Autowired
	private BarchartRepositoryValue repository;

	@PostConstruct
	private void init() {

	}
}
