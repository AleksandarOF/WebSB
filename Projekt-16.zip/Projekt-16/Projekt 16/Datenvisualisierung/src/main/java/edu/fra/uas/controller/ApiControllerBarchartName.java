package edu.fra.uas.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import org.springframework.web.bind.annotation.RestController;

import edu.fra.uas.model.Barchart;
import edu.fra.uas.repository.BarchartRepositoryName;

@RestController
@RequestMapping(value = "/api/barchart") // Hier finden wir alle gegeben Dateien in der JSON
public class ApiControllerBarchartName {

	@Autowired
	private BarchartRepositoryName repository;

	// GET request to retrieve all bar chart data
	@GetMapping
	public ResponseEntity<List<Barchart>> getAll() {
		return new ResponseEntity<>(this.repository.findAll(), HttpStatus.OK);

	}

	// POST request to save bar chart chart data
	@PostMapping()
	public ResponseEntity<String> saveBarchart(@RequestBody Barchart barchart) {
		this.repository.save(barchart);
		return new ResponseEntity<>("Barchart is saved", HttpStatus.ACCEPTED);
	}

}
