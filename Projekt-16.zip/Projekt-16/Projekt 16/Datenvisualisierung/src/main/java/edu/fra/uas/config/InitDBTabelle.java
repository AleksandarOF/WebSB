package edu.fra.uas.config;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.fra.uas.repository.TabelleRepository;

//This class initializes the database with default values for table if needed.

@Component
public class InitDBTabelle {

	@Autowired
	private TabelleRepository repository;

	@PostConstruct
	private void init() {

	}
}
