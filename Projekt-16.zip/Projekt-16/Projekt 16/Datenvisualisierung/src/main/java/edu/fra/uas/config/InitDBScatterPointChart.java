package edu.fra.uas.config;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


import edu.fra.uas.repository.ScatterPointChartRepository;

//This class initializes the database with default values for scatter point chart if needed.

@Component
public class InitDBScatterPointChart {

	@Autowired
	private ScatterPointChartRepository repository;
	
	@PostConstruct
	private void init() {
		
	}
}
