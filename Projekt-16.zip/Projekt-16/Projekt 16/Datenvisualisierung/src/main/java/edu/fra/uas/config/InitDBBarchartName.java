package edu.fra.uas.config;

import javax.annotation.PostConstruct;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import edu.fra.uas.repository.BarchartRepositoryName;

//This class initializes the database with default values for area chart if needed.

@Component
public class InitDBBarchartName {

	@Autowired
	private BarchartRepositoryName repository;

	@PostConstruct
	private void init() {

	}
}
