package edu.fra.uas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.fra.uas.model.AreaChart;

public interface AreaChartRepository extends JpaRepository<AreaChart, Long> {

}
