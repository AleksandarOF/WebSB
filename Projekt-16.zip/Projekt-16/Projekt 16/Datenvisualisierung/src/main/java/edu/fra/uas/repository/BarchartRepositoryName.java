package edu.fra.uas.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.fra.uas.model.Barchart;

public interface BarchartRepositoryName extends JpaRepository<Barchart, Long> {
	

}
